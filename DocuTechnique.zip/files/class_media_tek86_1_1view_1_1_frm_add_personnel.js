var class_media_tek86_1_1view_1_1_frm_add_personnel =
[
    [ "FrmAddPersonnel", "class_media_tek86_1_1view_1_1_frm_add_personnel.html#aa0264c5f4167769c48b962e43adc7507", null ],
    [ "Dispose", "class_media_tek86_1_1view_1_1_frm_add_personnel.html#a63cbdfe03bb41d090899acee7353c6e9", null ]
];