var namespaces_dup =
[
    [ "MediaTek86", "namespace_media_tek86.html", "namespace_media_tek86" ]
];