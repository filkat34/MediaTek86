var dir_da92606663f4ecb03aa66c183f15dac3 =
[
    [ "MediaTek86", "dir_26c0a546db9ea9046a38ab8861efeb5c.html", "dir_26c0a546db9ea9046a38ab8861efeb5c" ]
];