var class_media_tek86_1_1model_1_1_admin =
[
    [ "Admin", "class_media_tek86_1_1model_1_1_admin.html#af40078762ec9d9cf4b8ebbddad689a4d", null ],
    [ "Login", "class_media_tek86_1_1model_1_1_admin.html#a6104654c3fc4ca848d25bef4329d194e", null ],
    [ "Pwd", "class_media_tek86_1_1model_1_1_admin.html#a733f34d6600ded25ed53ebee095a1578", null ]
];