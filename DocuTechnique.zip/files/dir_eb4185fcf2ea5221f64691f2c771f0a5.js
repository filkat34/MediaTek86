var dir_eb4185fcf2ea5221f64691f2c771f0a5 =
[
    [ ".NETFramework,Version=v4.8.AssemblyAttributes.cs", "_debug_2_8_n_e_t_framework_00_version_0av4_88_8_assembly_attributes_8cs.html", null ]
];