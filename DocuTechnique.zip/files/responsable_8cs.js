var responsable_8cs =
[
    [ "MediaTek86.model.Responsable", "class_media_tek86_1_1model_1_1_responsable.html", "class_media_tek86_1_1model_1_1_responsable" ]
];