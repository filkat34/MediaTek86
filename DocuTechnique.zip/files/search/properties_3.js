var searchData=
[
  ['mail_0',['Mail',['../class_media_tek86_1_1model_1_1_personnel.html#a6ef6863c8aebf240b55a94990ca58ae9',1,'MediaTek86::model::Personnel']]],
  ['manager_1',['Manager',['../class_media_tek86_1_1dal_1_1_access.html#a96d165a05898f92205c892725c6aacbb',1,'MediaTek86::dal::Access']]]
];
