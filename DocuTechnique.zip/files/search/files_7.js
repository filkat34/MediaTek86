var searchData=
[
  ['service_2ecs_0',['service.cs',['../service_8cs.html',1,'']]],
  ['settings_2edesigner_2ecs_1',['Settings.Designer.cs',['../_settings_8_designer_8cs.html',1,'']]]
];
