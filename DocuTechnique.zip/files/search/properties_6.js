var searchData=
[
  ['service_0',['Service',['../class_media_tek86_1_1model_1_1_personnel.html#abdf4a6c86fc31227d393d96566ddd887',1,'MediaTek86::model::Personnel']]]
];
