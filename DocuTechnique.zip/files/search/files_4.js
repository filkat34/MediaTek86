var searchData=
[
  ['motif_2ecs_0',['motif.cs',['../motif_8cs.html',1,'']]]
];
