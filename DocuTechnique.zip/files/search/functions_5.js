var searchData=
[
  ['motif_0',['Motif',['../class_media_tek86_1_1model_1_1_motif.html#adcd35e0fa206432404760c3fd7a924ff',1,'MediaTek86::model::Motif']]]
];
