var dir_e65e897fae601578d7ef3d1d43398852 =
[
    [ ".NETFramework,Version=v4.8.AssemblyAttributes.cs", "_release_2_8_n_e_t_framework_00_version_0av4_88_8_assembly_attributes_8cs.html", null ]
];