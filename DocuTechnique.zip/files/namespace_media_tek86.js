var namespace_media_tek86 =
[
    [ "bddmanager", "namespace_media_tek86_1_1bddmanager.html", "namespace_media_tek86_1_1bddmanager" ],
    [ "controller", "namespace_media_tek86_1_1controller.html", "namespace_media_tek86_1_1controller" ],
    [ "dal", "namespace_media_tek86_1_1dal.html", "namespace_media_tek86_1_1dal" ],
    [ "model", "namespace_media_tek86_1_1model.html", "namespace_media_tek86_1_1model" ],
    [ "Properties", "namespace_media_tek86_1_1_properties.html", null ],
    [ "view", "namespace_media_tek86_1_1view.html", "namespace_media_tek86_1_1view" ]
];