var annotated_dup =
[
    [ "MediaTek86", "namespace_media_tek86.html", [
      [ "bddmanager", "namespace_media_tek86_1_1bddmanager.html", [
        [ "BddManager", "class_media_tek86_1_1bddmanager_1_1_bdd_manager.html", "class_media_tek86_1_1bddmanager_1_1_bdd_manager" ]
      ] ],
      [ "controller", "namespace_media_tek86_1_1controller.html", [
        [ "FrmAuthentificationController", "class_media_tek86_1_1controller_1_1_frm_authentification_controller.html", "class_media_tek86_1_1controller_1_1_frm_authentification_controller" ],
        [ "FrmGestionPersonnelController", "class_media_tek86_1_1controller_1_1_frm_gestion_personnel_controller.html", "class_media_tek86_1_1controller_1_1_frm_gestion_personnel_controller" ]
      ] ],
      [ "dal", "namespace_media_tek86_1_1dal.html", [
        [ "Access", "class_media_tek86_1_1dal_1_1_access.html", "class_media_tek86_1_1dal_1_1_access" ],
        [ "ResponsableAccess", "class_media_tek86_1_1dal_1_1_responsable_access.html", "class_media_tek86_1_1dal_1_1_responsable_access" ]
      ] ],
      [ "model", "namespace_media_tek86_1_1model.html", [
        [ "Absence", "class_media_tek86_1_1model_1_1_absence.html", "class_media_tek86_1_1model_1_1_absence" ],
        [ "Admin", "class_media_tek86_1_1model_1_1_admin.html", "class_media_tek86_1_1model_1_1_admin" ],
        [ "Motif", "class_media_tek86_1_1model_1_1_motif.html", "class_media_tek86_1_1model_1_1_motif" ],
        [ "Personnel", "class_media_tek86_1_1model_1_1_personnel.html", "class_media_tek86_1_1model_1_1_personnel" ],
        [ "Responsable", "class_media_tek86_1_1model_1_1_responsable.html", "class_media_tek86_1_1model_1_1_responsable" ],
        [ "Service", "class_media_tek86_1_1model_1_1_service.html", "class_media_tek86_1_1model_1_1_service" ]
      ] ],
      [ "view", "namespace_media_tek86_1_1view.html", [
        [ "FrmAddAbsence", "class_media_tek86_1_1view_1_1_frm_add_absence.html", "class_media_tek86_1_1view_1_1_frm_add_absence" ],
        [ "FrmAddPersonnel", "class_media_tek86_1_1view_1_1_frm_add_personnel.html", "class_media_tek86_1_1view_1_1_frm_add_personnel" ],
        [ "FrmAuthentification", "class_media_tek86_1_1view_1_1_frm_authentification.html", "class_media_tek86_1_1view_1_1_frm_authentification" ],
        [ "FrmGestionAbsence", "class_media_tek86_1_1view_1_1_frm_gestion_absence.html", "class_media_tek86_1_1view_1_1_frm_gestion_absence" ],
        [ "FrmGestionPersonnel", "class_media_tek86_1_1view_1_1_frm_gestion_personnel.html", "class_media_tek86_1_1view_1_1_frm_gestion_personnel" ],
        [ "FrmModAbsence", "class_media_tek86_1_1view_1_1_frm_mod_absence.html", "class_media_tek86_1_1view_1_1_frm_mod_absence" ],
        [ "FrmModPersonnel", "class_media_tek86_1_1view_1_1_frm_mod_personnel.html", "class_media_tek86_1_1view_1_1_frm_mod_personnel" ]
      ] ]
    ] ]
];