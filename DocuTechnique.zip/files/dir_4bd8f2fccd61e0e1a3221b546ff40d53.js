var dir_4bd8f2fccd61e0e1a3221b546ff40d53 =
[
    [ "AssemblyInfo.cs", "_assembly_info_8cs.html", null ],
    [ "Resources.Designer.cs", "_resources_8_designer_8cs.html", null ],
    [ "Settings.Designer.cs", "_settings_8_designer_8cs.html", null ]
];