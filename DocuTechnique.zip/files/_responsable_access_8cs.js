var _responsable_access_8cs =
[
    [ "MediaTek86.dal.ResponsableAccess", "class_media_tek86_1_1dal_1_1_responsable_access.html", "class_media_tek86_1_1dal_1_1_responsable_access" ]
];