var motif_8cs =
[
    [ "MediaTek86.model.Motif", "class_media_tek86_1_1model_1_1_motif.html", "class_media_tek86_1_1model_1_1_motif" ]
];