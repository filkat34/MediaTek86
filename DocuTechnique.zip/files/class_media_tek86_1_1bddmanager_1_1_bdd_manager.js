var class_media_tek86_1_1bddmanager_1_1_bdd_manager =
[
    [ "ReqSelect", "class_media_tek86_1_1bddmanager_1_1_bdd_manager.html#ad906eecd77ff1e05d56a42eec9dbee3b", null ],
    [ "ReqUpdate", "class_media_tek86_1_1bddmanager_1_1_bdd_manager.html#aac3a7cc7485d14495f2212a0eaed8456", null ]
];